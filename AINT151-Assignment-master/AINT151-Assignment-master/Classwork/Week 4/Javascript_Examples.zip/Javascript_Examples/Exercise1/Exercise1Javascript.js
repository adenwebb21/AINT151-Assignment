function AlertMessage()
{
  alert("You have been alerted!");
}


function ConsoleMessage()
{
  console.log("Console is active.");
}


function WhatsMyName()
{
  var firstName = "Jon";
  var lastName = "Brown";

  console.log(firstName + " " + lastName);
}
